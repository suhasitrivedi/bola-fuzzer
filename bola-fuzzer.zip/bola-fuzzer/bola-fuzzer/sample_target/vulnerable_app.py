import itertools
import uuid

from flask import Flask, jsonify, request

app = Flask(__name__)

USERS = {}      
TOKENS = {}      
NOTES = {} 
_id_counter = itertools.count(1)


def _user_for_token():
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return None
    token = auth[len("Bearer "):]
    user_id = TOKENS.get(token)
    if not user_id:
        return None
    for u in USERS.values():
        if u["id"] == user_id:
            return u
    return None


@app.post("/auth/register")
def register():
    body = request.get_json(force=True) or {}
    email, password = body.get("email"), body.get("password")
    if not email or not password:
        return jsonify({"error": "email and password required"}), 400
    if email in USERS:
        return jsonify({"error": "already registered"}), 409
    user_id = str(uuid.uuid4())
    USERS[email] = {"id": user_id, "email": email, "password": password}
    return jsonify({"id": user_id, "email": email}), 201


@app.post("/auth/login")
def login():
    body = request.get_json(force=True) or {}
    email, password = body.get("email"), body.get("password")
    user = USERS.get(email)
    if not user or user["password"] != password:
        return jsonify({"error": "invalid credentials"}), 401
    token = str(uuid.uuid4())
    TOKENS[token] = user["id"]
    return jsonify({"token": token, "user_id": user["id"]}), 200


@app.get("/auth/me")
def me():
    user = _user_for_token()
    if not user:
        return jsonify({"error": "unauthorized"}), 401
    return jsonify({"id": user["id"], "email": user["email"]}), 200


@app.post("/notes")
def create_note():
    user = _user_for_token()
    if not user:
        return jsonify({"error": "unauthorized"}), 401
    body = request.get_json(force=True) or {}
    note_id = next(_id_counter)
    note = {
        "id": note_id,
        "owner_id": user["id"],
        "title": body.get("title", ""),
        "content": body.get("content", ""),
    }
    NOTES[note_id] = note
    return jsonify(note), 201


@app.get("/notes/<int:note_id>")
def get_note(note_id):
    user = _user_for_token()
    if not user:
        return jsonify({"error": "unauthorized"}), 401
    note = NOTES.get(note_id)
    if not note:
        return jsonify({"error": "not found"}), 404
    # VULNERABLE: no ownership check.
    return jsonify(note), 200


@app.put("/notes/<int:note_id>")
def update_note(note_id):
    user = _user_for_token()
    if not user:
        return jsonify({"error": "unauthorized"}), 401
    note = NOTES.get(note_id)
    if not note:
        return jsonify({"error": "not found"}), 404
    body = request.get_json(force=True) or {}
    # VULNERABLE: no ownership check before mutating.
    if "title" in body:
        note["title"] = body["title"]
    if "content" in body:
        note["content"] = body["content"]
    return jsonify(note), 200


@app.delete("/notes/<int:note_id>")
def delete_note(note_id):
    user = _user_for_token()
    if not user:
        return jsonify({"error": "unauthorized"}), 401
    note = NOTES.get(note_id)
    if not note:
        return jsonify({"error": "not found"}), 404
    # VULNERABLE: no ownership check before deleting.
    del NOTES[note_id]
    return "", 204


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)
