from __future__ import annotations

import random
import re
import string
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .cleanup import CleanupRegistry
from .identity import DualIdentityHarness
from .oracle import ProbeEvidence, VerdictResult, evaluate
from .payload_gen import fake_body
from .spec_parser import DependencyGraph, Endpoint, Lifecycle

TARGET_OPS = ("GET", "PUT", "DELETE")  # PATCH substituted for PUT automatically if PUT absent


def _fill_path(template: str, values: Dict[str, str]) -> str:
    def repl(m):
        name = m.group(1)
        return str(values.get(name, m.group(0)))
    return re.sub(r"\{([^}]+)\}", repl, template)


def _first_path_param(ep: Endpoint) -> Optional[str]:
    return ep.path_params[0] if ep.path_params else None


def _extract_id(body: Any, candidates: List[str]) -> Optional[str]:
    if not isinstance(body, dict):
        return None
    for key in candidates + ["id"]:
        if key in body and body[key] is not None:
            return str(body[key])
    for v in body.values():
        if isinstance(v, dict):
            for key in candidates + ["id"]:
                if key in v and v[key] is not None:
                    return str(v[key])
    return None


def _snapshot_with_status(resp) -> Any:
    try:
        body = resp.json()
    except ValueError:
        body = {}
    if isinstance(body, dict):
        body = dict(body)
        body["_http_status"] = resp.status_code
        return body
    return {"_http_status": resp.status_code, "_raw": body}


@dataclass
class EngineConfig:
    marker_prefix: str = "BOLAFUZZ-MARKER-"
    rate_limit_delay_s: float = 0.0


@dataclass
class TestRunResult:
    results: List[VerdictResult] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


class ReplayEngine:
    def __init__(
        self,
        spec: dict,
        graph: DependencyGraph,
        harness: DualIdentityHarness,
        cleanup: CleanupRegistry,
        config: Optional[EngineConfig] = None,
    ):
        self.spec = spec
        self.graph = graph
        self.harness = harness
        self.cleanup = cleanup
        self.config = config or EngineConfig()

    # ---- helpers -------------------------------------------------------

    def _create_as(self, identity, lifecycle: Lifecycle, tag: str):
        create_ep = lifecycle.create
        body = fake_body(self._request_body_schema(create_ep), self.spec)
        body["_fuzz_tag"] = f"bolafuzz-{tag}-{uuid.uuid4().hex[:8]}"
        resp = identity.request("post", lifecycle.resource, json=body)
        return resp

    def _request_body_schema(self, ep: Endpoint) -> dict:
        # Re-derive schema dict (not just field names) straight from the spec.
        try:
            op = self.spec["paths"][ep.path][ep.method]
            return op.get("requestBody", {}).get("content", {}).get("application/json", {}).get("schema", {})
        except KeyError:
            return {}

    def _id_candidates(self, ep: Endpoint) -> List[str]:
        param = _first_path_param(ep)
        cands = list(ep.response_id_fields)
        if param:
            cands.append(param)
        return cands

    def _consumer_url_for(self, consumer: Endpoint, resource_id: str) -> str:
        param = _first_path_param(consumer)
        values = {param: resource_id} if param else {}
        return _fill_path(consumer.path, values)

    def _do_op(self, identity, method: str, url: str, json_body: Optional[dict] = None):
        return identity.request(method, url, json=json_body)

    # ---- Algorithm 1 -----------------------------------------------------

    def run_lifecycle(self, lifecycle: Lifecycle, run: TestRunResult) -> None:
        # Determine which of GET/PUT(or PATCH)/DELETE are actually exposed
        # for this resource, per the dependency graph (Section 4.2/4.4).
        ops_available: Dict[str, Endpoint] = {}
        for c in lifecycle.consumers:
            m = c.method.upper()
            if m == "GET":
                ops_available["GET"] = c
            elif m in ("PUT", "PATCH") and "PUT" not in ops_available and "PATCH" not in ops_available:
                ops_available[m] = c
            elif m == "DELETE":
                ops_available["DELETE"] = c

        for op_name, consumer_ep in ops_available.items():
            try:
                self._test_one_operation(lifecycle, op_name, consumer_ep, run)
            except Exception as e:  # keep going across the rest of the suite
                run.errors.append(f"[{lifecycle.resource} {op_name}] {type(e).__name__}: {e}")

    def _test_one_operation(self, lifecycle: Lifecycle, op_name: str, consumer_ep: Endpoint, run: TestRunResult):
        a, b = self.harness.a, self.harness.b

        # 1. A creates resource R
        create_resp = self._create_as(a, lifecycle, tag="A")
        if create_resp.status_code >= 300:
            run.errors.append(
                f"[{lifecycle.resource} {op_name}] A's create failed "
                f"(HTTP {create_resp.status_code}); skipping this test."
            )
            return
        create_body = create_resp.json() if create_resp.content else {}
        id_candidates = self._id_candidates(consumer_ep)
        resource_id = _extract_id(create_body, id_candidates)
        if resource_id is None:
            run.errors.append(
                f"[{lifecycle.resource} {op_name}] Could not find an identifier field in A's "
                f"create response ({list(create_body.keys()) if isinstance(create_body, dict) else create_body}); skipping."
            )
            return
        self.cleanup.register(consumer_ep.path, resource_id, created_by="A")
        url = self._consumer_url_for(consumer_ep, resource_id)

        # 2. A reads id -> S0
        get_ep_for_read = self._find_get_endpoint(lifecycle) or consumer_ep
        read_url = self._consumer_url_for(get_ep_for_read, resource_id) if get_ep_for_read.method == "get" else url
        s0_resp = a.request("get", read_url)
        s0 = _snapshot_with_status(s0_resp)

        # 3a. Positive control: B does op on a resource B owns.
        b_create_resp = self._create_as(b, lifecycle, tag="B")
        positive_control_status = None
        b_resource_id = None
        if b_create_resp.status_code < 300:
            b_body = b_create_resp.json() if b_create_resp.content else {}
            b_resource_id = _extract_id(b_body, id_candidates)
            if b_resource_id is not None:
                self.cleanup.register(consumer_ep.path, b_resource_id, created_by="B")
                b_own_url = self._consumer_url_for(consumer_ep, b_resource_id)
                marker_field, marker_value = self._marker_for(consumer_ep)
                pc_resp = self._do_op(
                    b, op_name.lower(), b_own_url,
                    json_body={marker_field: marker_value} if op_name in ("PUT", "PATCH") else None,
                )
                positive_control_status = pc_resp.status_code

        # 3b. Negative control: B does op on a random/non-existent id.
        fake_id = str(uuid.uuid4())
        neg_url = self._consumer_url_for(consumer_ep, fake_id)
        neg_resp = self._do_op(b, op_name.lower(), neg_url)
        negative_control_status = neg_resp.status_code

        # 3c. Unauthenticated client GETs id (public check) - always GET.
        anon_read_url = self._consumer_url_for(get_ep_for_read, resource_id) if get_ep_for_read.method == "get" else url
        unauth_status, unauth_body = None, None
        try:
            unauth_resp = self.harness.anon_request("get", anon_read_url)
            unauth_status = unauth_resp.status_code
            unauth_body = unauth_resp.json() if unauth_resp.content else None
        except Exception:
            pass

        # 4. Probe: B does op on A's id.
        marker_field, marker_value = (None, None)
        probe_json = None
        if op_name in ("PUT", "PATCH"):
            marker_field, marker_value = self._marker_for(consumer_ep)
            probe_json = {marker_field: marker_value}
        probe_resp = self._do_op(b, op_name.lower(), url, json_body=probe_json)
        try:
            probe_body = probe_resp.json() if probe_resp.content else None
        except ValueError:
            probe_body = None

        # 5. Verify: A re-reads id -> S1.
        s1_resp = a.request("get", read_url)
        s1 = _snapshot_with_status(s1_resp)
        if op_name == "DELETE" and s1_resp.status_code in (404, 410):
            self.cleanup.mark_deleted(resource_id)

        evidence = ProbeEvidence(
            operation=op_name,
            resource_path=consumer_ep.path,
            probe_status=probe_resp.status_code,
            probe_body=probe_body,
            owner_snapshot_before=s0,
            owner_snapshot_after=s1,
            unauthenticated_status=unauth_status,
            unauthenticated_body=unauth_body,
            negative_control_status=negative_control_status,
            positive_control_status=positive_control_status,
            marker_value=marker_value,
            marker_field=marker_field,
        )
        verdict = evaluate(evidence)
        run.results.append(verdict)

        # 7. Cleanup: delete R (and B's resource, if not already consumed by DELETE probe).
        self._cleanup_resource(consumer_ep, resource_id, already_deleted=(op_name == "DELETE" and s1_resp.status_code in (404, 410)))
        if b_resource_id is not None:
            self._cleanup_resource(consumer_ep, b_resource_id, already_deleted=(op_name == "DELETE"))

    def _marker_for(self, consumer_ep: Endpoint) -> (str, str):
        schema = self._request_body_schema(consumer_ep)
        resolved = schema
        if "$ref" in resolved:
            resolved = self._resolve_ref(resolved["$ref"])
        props = (resolved or {}).get("properties", {})
        field_name = None
        for pname, pschema in props.items():
            low = pname.lower()
            if low == "id" or low.endswith("id"):
                continue
            if (pschema or {}).get("type", "string") == "string":
                field_name = pname
                break
        field_name = field_name or next(iter(props.keys()), None) or "fuzz_marker"
        value = f"{self.config.marker_prefix}{uuid.uuid4().hex[:10]}"
        return field_name, value

    def _resolve_ref(self, ref: str) -> dict:
        if not ref.startswith("#/"):
            return {}
        node = self.spec
        for part in ref[2:].split("/"):
            node = node.get(part, {})
        return node

    def _find_get_endpoint(self, lifecycle: Lifecycle) -> Optional[Endpoint]:
        for c in lifecycle.consumers:
            if c.method == "get":
                return c
        return None

    def _cleanup_resource(self, consumer_ep: Endpoint, resource_id: str, already_deleted: bool) -> None:
        if already_deleted:
            self.cleanup.mark_deleted(resource_id)
            return
        delete_ep_path = consumer_ep.path  # same resource path template
        url = _fill_path(delete_ep_path, {_first_path_param(consumer_ep): resource_id} if _first_path_param(consumer_ep) else {})
        try:
            resp = self.harness.a.request("delete", url)
            if resp.status_code < 300 or resp.status_code in (404, 410):
                self.cleanup.mark_deleted(resource_id)
        except Exception:
            pass  # best-effort cleanup; left in the registry for manual follow-up

    # ---- entry point -------------------------------------------------------

    def run(self) -> TestRunResult:
        run = TestRunResult()
        self.harness.setup()
        for lifecycle in self.graph.lifecycles:
            self.run_lifecycle(lifecycle, run)
        return run
