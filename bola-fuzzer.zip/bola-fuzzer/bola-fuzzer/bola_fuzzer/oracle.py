from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Optional

VOLATILE_FIELDS = {
    "updated_at", "updatedAt", "modified_at", "modifiedAt",
    "created_at", "createdAt", "timestamp", "last_modified", "lastModified",
}


class Verdict(str, Enum):
    CONFIRMED_BOLA = "confirmed_bola"
    SUSPECTED_BOLA = "suspected_bola"
    NOT_VULNERABLE = "not_vulnerable"
    PUBLIC_RESOURCE = "public_resource"
    INCONCLUSIVE = "inconclusive"


@dataclass
class ProbeEvidence:
    operation: str                      # GET | PUT | PATCH | DELETE
    resource_path: str
    probe_status: int
    probe_body: Any
    owner_snapshot_before: Any          # S0
    owner_snapshot_after: Any           # S1 (post-verification re-fetch by A)
    unauthenticated_status: Optional[int] = None
    unauthenticated_body: Any = None
    negative_control_status: Optional[int] = None   # B against random/non-existent id
    positive_control_status: Optional[int] = None    # B against own resource, same op
    marker_value: Optional[str] = None               # unique value B tried to write (PUT/PATCH)
    marker_field: Optional[str] = None


@dataclass
class VerdictResult:
    verdict: Verdict
    operation: str
    resource_path: str
    rationale: str
    evidence: ProbeEvidence


def _strip_volatile(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _strip_volatile(v) for k, v in obj.items() if k not in VOLATILE_FIELDS}
    if isinstance(obj, list):
        return [_strip_volatile(v) for v in obj]
    return obj


def _bodies_equal(a: Any, b: Any) -> bool:
    return _strip_volatile(a) == _strip_volatile(b)


def _body_contains_owner_identity(body: Any, owner_snapshot: Any) -> bool:
    """Checks whether `body` plausibly contains A's object: same id, or a
    field-level match against A's baseline snapshot on at least one
    distinguishing (non-volatile) field."""
    if not isinstance(body, dict) or not isinstance(owner_snapshot, dict):
        return False
    a_clean = _strip_volatile(owner_snapshot)
    b_clean = _strip_volatile(body)
    if "id" in a_clean and "id" in b_clean and a_clean["id"] == b_clean["id"]:
        return True
    shared_keys = set(a_clean.keys()) & set(b_clean.keys())
    shared_keys.discard("id")
    matches = sum(1 for k in shared_keys if a_clean[k] == b_clean[k])
    return len(shared_keys) > 0 and matches == len(shared_keys)


def evaluate_get(ev: ProbeEvidence) -> VerdictResult:
    # Table 2, GET row.
    if 200 <= ev.probe_status < 300 and _body_contains_owner_identity(ev.probe_body, ev.owner_snapshot_before):
        unauth_ok = ev.unauthenticated_status is not None and 200 <= ev.unauthenticated_status < 300
        if unauth_ok and _body_contains_owner_identity(ev.unauthenticated_body, ev.owner_snapshot_before):
            return VerdictResult(
                Verdict.PUBLIC_RESOURCE, "GET", ev.resource_path,
                "B retrieved A's resource, but an unauthenticated request also succeeds, "
                "so this endpoint is public by design rather than object-level broken.",
                ev,
            )
        return VerdictResult(
            Verdict.CONFIRMED_BOLA, "GET", ev.resource_path,
            f"B received HTTP {ev.probe_status} and the body matches A's resource; "
            "the unauthenticated check did not also succeed, so access control was "
            "bypassed specifically by B's authenticated-but-wrong-owner request.",
            ev,
        )
    if ev.probe_status in (401, 403) or (
        ev.negative_control_status is not None and ev.probe_status == ev.negative_control_status
    ):
        return VerdictResult(
            Verdict.NOT_VULNERABLE, "GET", ev.resource_path,
            f"B received HTTP {ev.probe_status}, consistent with the negative-control "
            "rejection pattern for this API.",
            ev,
        )
    if ev.probe_status == 404:
        return VerdictResult(
            Verdict.NOT_VULNERABLE, "GET", ev.resource_path,
            "B received HTTP 404 (resource existence masked), consistent with correctly "
            "denied cross-identity access.",
            ev,
        )
    return VerdictResult(
        Verdict.INCONCLUSIVE, "GET", ev.resource_path,
        f"Probe returned HTTP {ev.probe_status} with a body that does not clearly "
        "match or clearly reject; needs manual review.",
        ev,
    )


def evaluate_mutation(ev: ProbeEvidence, operation: str) -> VerdictResult:
    # Table 2, PUT/PATCH and DELETE rows.
    probe_ok = 200 <= ev.probe_status < 300 or ev.probe_status == 204

    if operation in ("PUT", "PATCH"):
        if probe_ok:
            after_has_marker = (
                isinstance(ev.owner_snapshot_after, dict)
                and ev.marker_field is not None
                and ev.owner_snapshot_after.get(ev.marker_field) == ev.marker_value
            )
            if after_has_marker:
                return VerdictResult(
                    Verdict.CONFIRMED_BOLA, operation, ev.resource_path,
                    f"B's request returned HTTP {ev.probe_status} and A's re-fetched resource "
                    f"now contains B's marker value in field '{ev.marker_field}', proving the "
                    "mutation actually took effect on the owner's data.",
                    ev,
                )
            if _bodies_equal(ev.owner_snapshot_before, ev.owner_snapshot_after):
                return VerdictResult(
                    Verdict.SUSPECTED_BOLA, operation, ev.resource_path,
                    f"B's request returned HTTP {ev.probe_status} (apparent success) but A's "
                    "data is unchanged after re-fetch; this may be a no-op, deferred write, "
                    "or an application that returns 2xx without applying the change. "
                    "Flagged for manual review rather than confirmed.",
                    ev,
                )
            return VerdictResult(
                Verdict.SUSPECTED_BOLA, operation, ev.resource_path,
                f"B's request returned HTTP {ev.probe_status} and A's snapshot changed, but "
                "not in the exact marker field expected; needs manual review.",
                ev,
            )
        return VerdictResult(
            Verdict.NOT_VULNERABLE, operation, ev.resource_path,
            f"B's request was rejected (HTTP {ev.probe_status}).",
            ev,
        )

    if operation == "DELETE":
        if probe_ok:
            owner_gone = isinstance(ev.owner_snapshot_after, dict) and ev.owner_snapshot_after.get(
                "_http_status"
            ) in (404, 410)
            if owner_gone:
                return VerdictResult(
                    Verdict.CONFIRMED_BOLA, operation, ev.resource_path,
                    f"B's delete returned HTTP {ev.probe_status} and A's resource is now "
                    "unreachable (404/410) where it previously existed, confirming the "
                    "deletion actually took effect.",
                    ev,
                )
            return VerdictResult(
                Verdict.SUSPECTED_BOLA, operation, ev.resource_path,
                f"B's delete returned HTTP {ev.probe_status} (apparent success) but A's "
                "resource still exists on re-fetch; flagged for manual review rather than "
                "confirmed.",
                ev,
            )
        return VerdictResult(
            Verdict.NOT_VULNERABLE, operation, ev.resource_path,
            f"B's delete was rejected (HTTP {ev.probe_status}).",
            ev,
        )

    raise ValueError(f"Unsupported mutation operation: {operation}")


def evaluate(ev: ProbeEvidence) -> VerdictResult:
    op = ev.operation.upper()
    if op == "GET":
        return evaluate_get(ev)
    if op in ("PUT", "PATCH", "DELETE"):
        return evaluate_mutation(ev, op)
    raise ValueError(f"Unsupported operation for oracle: {op}")
