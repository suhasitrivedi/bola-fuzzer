from __future__ import annotations

import itertools
import random
import string
from typing import Any, Optional

_counter = itertools.count(1)


def _resolve(schema: dict, spec: dict, depth: int = 0) -> dict:
    if depth > 6:
        return {}
    if "$ref" in schema:
        ref = schema["$ref"]
        if not ref.startswith("#/"):
            return {}
        node = spec
        for part in ref[2:].split("/"):
            node = node.get(part, {})
        return _resolve(node, spec, depth + 1)
    return schema


def _fake_string(name: str = "") -> str:
    n = next(_counter)
    low = name.lower()
    if "email" in low:
        return f"user{n}@example.com"
    if "name" in low or "title" in low:
        return f"Test {name or 'Value'} {n}"
    suffix = "".join(random.choices(string.ascii_lowercase, k=4))
    return f"fuzz-{n}-{suffix}"


def fake_value_for_schema(schema: dict, spec: dict, field_name: str = "", depth: int = 0) -> Any:
    schema = _resolve(schema or {}, spec)
    if not schema:
        return _fake_string(field_name)
    if "example" in schema:
        return schema["example"]
    if "default" in schema:
        return schema["default"]
    if "enum" in schema and schema["enum"]:
        return schema["enum"][0]

    typ = schema.get("type")
    if typ == "object" or "properties" in schema:
        out = {}
        props = schema.get("properties", {})
        required = set(schema.get("required", props.keys()))
        for pname, pschema in props.items():
            if pname in required and depth < 4:
                out[pname] = fake_value_for_schema(pschema, spec, pname, depth + 1)
        return out
    if typ == "array":
        item_schema = schema.get("items", {})
        return [fake_value_for_schema(item_schema, spec, field_name, depth + 1)] if depth < 3 else []
    if typ == "integer":
        return random.randint(1, 10_000)
    if typ == "number":
        return round(random.uniform(1, 1000), 2)
    if typ == "boolean":
        return True
    if typ == "string":
        fmt = schema.get("format")
        if fmt == "date-time":
            return "2026-01-01T00:00:00Z"
        if fmt == "date":
            return "2026-01-01"
        return _fake_string(field_name)
    return _fake_string(field_name)


def fake_body(body_schema: Optional[dict], spec: dict) -> dict:
    if not body_schema:
        return {}
    val = fake_value_for_schema(body_schema, spec)
    return val if isinstance(val, dict) else {"value": val}
