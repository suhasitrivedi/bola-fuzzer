from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

RUN_PREFIX = "bolafuzz-"


@dataclass
class CleanupEntry:
    resource_path: str   # e.g. /notes/{id}
    resource_id: str
    created_by: str       # "A" or "B"
    deleted: bool = False


@dataclass
class CleanupRegistry:
    entries: List[CleanupEntry] = field(default_factory=list)
    log_path: str = "reports/cleanup_registry.json"

    def register(self, resource_path: str, resource_id: str, created_by: str) -> None:
        self.entries.append(CleanupEntry(resource_path, str(resource_id), created_by))
        self._flush()

    def mark_deleted(self, resource_id: str) -> None:
        for e in self.entries:
            if e.resource_id == str(resource_id):
                e.deleted = True
        self._flush()

    def pending(self) -> List[CleanupEntry]:
        return [e for e in self.entries if not e.deleted]

    def _flush(self) -> None:
        Path(self.log_path).parent.mkdir(parents=True, exist_ok=True)
        with open(self.log_path, "w") as f:
            json.dump([e.__dict__ for e in self.entries], f, indent=2)
