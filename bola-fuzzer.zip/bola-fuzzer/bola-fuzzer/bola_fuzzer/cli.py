from __future__ import annotations

import argparse
import json
import sys

import yaml

from .cleanup import CleanupRegistry
from .engine import EngineConfig, ReplayEngine
from .identity import DualIdentityHarness, IdentityConfig
from .report import print_console_summary, write_json_report
from .spec_parser import parse_spec


def load_config(path: str) -> dict:
    text = open(path).read()
    if path.endswith((".yaml", ".yml")):
        return yaml.safe_load(text)
    return json.loads(text)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Dual-identity BOLA fuzzer")
    ap.add_argument("--config", required=True, help="Path to config.yaml")
    ap.add_argument("--report", default="reports/report.json", help="Output path for the JSON report")
    ap.add_argument("--include", nargs="*", default=None, help="Force-include these path templates")
    ap.add_argument("--exclude", nargs="*", default=None, help="Force-exclude these path templates")
    args = ap.parse_args(argv)

    cfg = load_config(args.config)

    spec_path = cfg["openapi_spec"]
    base_url = cfg["base_url"]

    graph = parse_spec(spec_path, include=args.include, exclude=args.exclude)
    print("Dependency graph:")
    print(graph.summary() or "  (no lifecycles with both a creator and an object-id consumer found)")
    if not graph.lifecycles:
        print("Nothing to test. Check your OpenAPI spec has POST creators matching GET/PUT/DELETE/{id} routes.")
        return 1

    id_a = IdentityConfig(**cfg["identity_a"])
    id_b = IdentityConfig(**cfg["identity_b"])
    delay = float(cfg.get("request_delay_s", 0.0))
    harness = DualIdentityHarness(base_url, id_a, id_b, delay)

    cleanup = CleanupRegistry(log_path=cfg.get("cleanup_log", "reports/cleanup_registry.json"))

    import yaml as _yaml
    from .spec_parser import _load_spec  # reuse loader for raw spec dict
    raw_spec = _load_spec(spec_path)

    engine = ReplayEngine(raw_spec, graph, harness, cleanup, EngineConfig())
    run = engine.run()

    print_console_summary(run)
    write_json_report(run, args.report)
    print(f"Full JSON report written to {args.report}")

    pending = cleanup.pending()
    if pending:
        print(f"WARNING: {len(pending)} test resource(s) could not be confirmed deleted; see {cleanup.log_path}")

    has_findings = any(r.verdict.value in ("confirmed_bola", "suspected_bola") for r in run.results)
    return 2 if has_findings else 0


if __name__ == "__main__":
    sys.exit(main())
