from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Optional

import requests


@dataclass
class IdentityConfig:
    name: str
    login_url: Optional[str] = None
    login_payload: Optional[dict] = None
    token: Optional[str] = None
    token_field: str = "token"
    auth_header: str = "Authorization"
    auth_scheme: str = "Bearer"
    whoami_url: Optional[str] = None
    whoami_id_field: str = "id"
    register_url: Optional[str] = None        
    register_payload: Optional[dict] = None 


class Identity:
    def __init__(self, cfg: IdentityConfig, base_url: str, session: Optional[requests.Session] = None, delay_s: float = 0.0):
        self.cfg = cfg
        self.base_url = base_url.rstrip("/")
        self.session = session or requests.Session()
        self.token: Optional[str] = cfg.token
        self.user_id: Optional[str] = None
        self.delay_s = delay_s
        self._static_token = bool(cfg.token) 
        self._registered = False

    def register(self) -> None:
        if not self.cfg.register_url or self._registered:
            return
        payload = self.cfg.register_payload or self.cfg.login_payload
        resp = self.session.post(self._url(self.cfg.register_url), json=payload, timeout=15)
        if resp.status_code >= 500:
            resp.raise_for_status()
        self._registered = True

    def login(self) -> None:
        if self.token:
            return
        if not self.cfg.login_url:
            raise ValueError(f"Identity '{self.cfg.name}' has neither a token nor a login_url configured.")
        self.register()
        resp = self.session.post(self._url(self.cfg.login_url), json=self.cfg.login_payload, timeout=15)
        resp.raise_for_status()
        body = resp.json()
        token = body.get(self.cfg.token_field)
        if not token:
            raise ValueError(
                f"Login for identity '{self.cfg.name}' succeeded (HTTP {resp.status_code}) but the "
                f"response had no '{self.cfg.token_field}' field. Got keys: {list(body.keys())}"
            )
        self.token = token

    def _url(self, path_or_url: str) -> str:
        if path_or_url.startswith("http://") or path_or_url.startswith("https://"):
            return path_or_url
        return self.base_url + "/" + path_or_url.lstrip("/")

    def auth_headers(self) -> dict:
        if not self.token:
            return {}
        value = f"{self.cfg.auth_scheme} {self.token}".strip()
        return {self.cfg.auth_header: value}

    def whoami(self) -> Optional[str]:
        if not self.cfg.whoami_url:
            return None
        resp = self.session.get(self._url(self.cfg.whoami_url), headers=self.auth_headers(), timeout=15)
        if resp.status_code >= 400:
            return None
        try:
            body = resp.json()
        except ValueError:
            return None
        self.user_id = str(body.get(self.cfg.whoami_id_field)) if body.get(self.cfg.whoami_id_field) is not None else None
        return self.user_id

    def _send(self, method: str, path_or_url: str, **kwargs) -> requests.Response:
        headers = dict(kwargs.pop("headers", {}) or {})
        headers.update(self.auth_headers())
        return self.session.request(method.upper(), self._url(path_or_url), headers=headers, timeout=15, **kwargs)

    def request(self, method: str, path_or_url: str, **kwargs) -> requests.Response:
        if self.delay_s:
            time.sleep(self.delay_s)
        resp = self._send(method, path_or_url, **kwargs)
        # Token refresh: if a login-obtained token expired (401), log in again once and retry.
        if resp.status_code == 401 and self.cfg.login_url and not self._static_token:
            self.token = None
            self.login()
            resp = self._send(method, path_or_url, **kwargs)
        return resp


class DualIdentityHarness:
    """Holds identities A (owner) and B (adversary) plus an unauthenticated client."""

    def __init__(self, base_url: str, identity_a: IdentityConfig, identity_b: IdentityConfig, delay_s: float = 0.0):
        self.base_url = base_url
        self.a = Identity(identity_a, base_url, delay_s=delay_s)
        self.b = Identity(identity_b, base_url, delay_s=delay_s)
        self.anon = requests.Session()

    def setup(self) -> None:
        self.a.login()
        self.b.login()
        self._sanity_check()

    def _sanity_check(self) -> None:
        id_a = self.a.whoami()
        id_b = self.b.whoami()
        if id_a is not None and id_b is not None and id_a == id_b:
            raise RuntimeError(
                "Identity sanity check failed: User A and User B resolved to the SAME "
                f"account (id={id_a}). Dual-identity testing requires two distinct, "
                "same-privilege accounts."
            )

    def anon_request(self, method: str, path_or_url: str, **kwargs) -> requests.Response:
        url = path_or_url if path_or_url.startswith("http") else self.base_url.rstrip("/") + "/" + path_or_url.lstrip("/")
        return self.anon.request(method.upper(), url, timeout=15, **kwargs)