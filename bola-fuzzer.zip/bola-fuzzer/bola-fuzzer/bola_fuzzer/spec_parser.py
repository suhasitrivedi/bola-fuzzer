from __future__ import annotations
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

import yaml

OBJECT_ID_OPS = ("get", "put", "patch", "delete")


@dataclass
class Endpoint:
    method: str                 
    path: str                 
    operation_id: Optional[str]
    path_params: List[str] = field(default_factory=list)
    is_explicitly_public: bool = False
    request_body_id_fields: List[str] = field(default_factory=list)
    response_id_fields: List[str] = field(default_factory=list)

    @property
    def has_object_id_param(self) -> bool:
        return len(self.path_params) > 0

    @property
    def resource_base(self) -> str:
        segments = self.path.rstrip("/").split("/")
        if segments and re.fullmatch(r"\{[^}]+\}", segments[-1]):
            return "/".join(segments[:-1]) or "/"
        return self.path


@dataclass
class Lifecycle:
    resource: str
    create: Optional[Endpoint]
    consumers: List[Endpoint] = field(default_factory=list)


@dataclass
class DependencyGraph:
    lifecycles: List[Lifecycle]

    def summary(self) -> str:
        lines = []
        for lc in self.lifecycles:
            create = f"{lc.create.method.upper()} {lc.create.path}" if lc.create else "(no creator found)"
            lines.append(f"- {lc.resource}: creator={create}")
            for c in lc.consumers:
                lines.append(f"    consumer: {c.method.upper()} {c.path}")
        return "\n".join(lines)


def _load_spec(path: str) -> dict:
    text = Path(path).read_text()
    if path.endswith((".yaml", ".yml")):
        return yaml.safe_load(text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return yaml.safe_load(text)


def _extract_id_fields_from_schema(schema: dict, spec: dict, _depth: int = 0) -> List[str]:
    if not schema or _depth > 4:
        return []
    if "$ref" in schema:
        schema = _resolve_ref(schema["$ref"], spec) or {}
    props = schema.get("properties", {})
    found = []
    for name in props:
        if name == "id" or name.endswith("Id") or name.endswith("_id"):
            found.append(name)
    return found


def _resolve_ref(ref: str, spec: dict) -> Optional[dict]:
    if not ref.startswith("#/"):
        return None
    node = spec
    for part in ref[2:].split("/"):
        node = node.get(part, {})
    return node


def _body_schema_for_operation(op: dict, spec: dict) -> dict:
    body = op.get("requestBody", {})
    content = body.get("content", {})
    json_body = content.get("application/json", {})
    return json_body.get("schema", {})


def _response_schema_for_operation(op: dict, spec: dict) -> dict:
    responses = op.get("responses", {})
    for code in ("200", "201"):
        resp = responses.get(code)
        if resp:
            content = resp.get("content", {})
            json_body = content.get("application/json", {})
            return json_body.get("schema", {})
    return {}


def _is_explicitly_public(op: dict, spec: dict) -> bool:
    if "security" in op:
        return op["security"] == []
    top_level = spec.get("security")
    if top_level is not None:
        return top_level == []
    return False


def parse_spec(
    spec_path: str,
    include: Optional[List[str]] = None,
    exclude: Optional[List[str]] = None,
) -> DependencyGraph:
    spec = _load_spec(spec_path)
    paths = spec.get("paths", {})

    endpoints: List[Endpoint] = []
    for raw_path, path_item in paths.items():
        path_params_in_template = re.findall(r"\{([^}]+)\}", raw_path)
        for method, op in path_item.items():
            if method.lower() not in ("get", "post", "put", "patch", "delete"):
                continue
            if not isinstance(op, dict):
                continue
            public = _is_explicitly_public(op, spec)
            ep = Endpoint(
                method=method.lower(),
                path=raw_path,
                operation_id=op.get("operationId"),
                path_params=path_params_in_template,
                is_explicitly_public=public,
                request_body_id_fields=_extract_id_fields_from_schema(
                    _body_schema_for_operation(op, spec), spec
                ),
                response_id_fields=_extract_id_fields_from_schema(
                    _response_schema_for_operation(op, spec), spec
                ),
            )
            endpoints.append(ep)

    include = set(include or [])
    exclude = set(exclude or [])

    def keep(ep: Endpoint) -> bool:
        if ep.path in exclude:
            return False
        if ep.path in include:
            return True
        if ep.is_explicitly_public:
            return False
        return True

    endpoints = [ep for ep in endpoints if keep(ep)]

    id_endpoints = [ep for ep in endpoints if ep.has_object_id_param and ep.method in OBJECT_ID_OPS]
    posts_by_path = {ep.path: ep for ep in endpoints if ep.method == "post"}

    lifecycles_by_resource: Dict[str, Lifecycle] = {}
    for ep in id_endpoints:
        base = ep.resource_base
        creator = posts_by_path.get(base)
        if base not in lifecycles_by_resource:
            lifecycles_by_resource[base] = Lifecycle(resource=base, create=creator, consumers=[])
        lifecycles_by_resource[base].consumers.append(ep)

    lifecycles = [lc for lc in lifecycles_by_resource.values() if lc.create is not None]
    skipped = [lc for lc in lifecycles_by_resource.values() if lc.create is None]
    if skipped:
        for lc in skipped:
            print(
                f"[spec_parser] WARNING: no creating (POST) operation found for "
                f"resource '{lc.resource}' - skipping {len(lc.consumers)} endpoint(s). "
                f"Add it to the dependency graph manually if needed."
            )

    return DependencyGraph(lifecycles=lifecycles)
