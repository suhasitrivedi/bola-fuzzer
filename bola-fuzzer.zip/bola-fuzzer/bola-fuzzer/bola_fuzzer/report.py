from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import List

from .engine import TestRunResult
from .oracle import Verdict, VerdictResult


def to_dict(v: VerdictResult) -> dict:
    d = asdict(v)
    d["verdict"] = v.verdict.value
    return d


def write_json_report(run: TestRunResult, path: str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "summary": summarize(run.results),
        "errors": run.errors,
        "findings": [to_dict(v) for v in run.results],
    }
    with open(path, "w") as f:
        json.dump(payload, f, indent=2, default=str)


def summarize(results: List[VerdictResult]) -> dict:
    counts = {v.value: 0 for v in Verdict}
    for r in results:
        counts[r.verdict.value] += 1
    counts["total_tests"] = len(results)
    return counts


def print_console_summary(run: TestRunResult) -> None:
    counts = summarize(run.results)
    print("\n=== BOLA Fuzzer Summary ===")
    print(f"Total tests run:      {counts['total_tests']}")
    print(f"Confirmed BOLA:       {counts[Verdict.CONFIRMED_BOLA.value]}")
    print(f"Suspected BOLA:       {counts[Verdict.SUSPECTED_BOLA.value]}")
    print(f"Public resource:      {counts[Verdict.PUBLIC_RESOURCE.value]}")
    print(f"Not vulnerable:       {counts[Verdict.NOT_VULNERABLE.value]}")
    print(f"Inconclusive:         {counts[Verdict.INCONCLUSIVE.value]}")
    if run.errors:
        print(f"\nErrors / skipped tests: {len(run.errors)}")
        for e in run.errors:
            print(f"  - {e}")

    confirmed = [r for r in run.results if r.verdict in (Verdict.CONFIRMED_BOLA, Verdict.SUSPECTED_BOLA)]
    if confirmed:
        print("\n--- Findings ---")
        for r in confirmed:
            print(f"[{r.verdict.value.upper()}] {r.operation} {r.resource_path}")
            print(f"    {r.rationale}")
    print()
